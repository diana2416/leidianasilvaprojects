<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<style>
	#nav { font-family: sans-serif; font-size: 14px; width: 100%; float: left; margin: 0 0 1em 0; padding: 0; list-style: none;}
	#nav {list-style: none; border:0;}
	#rightnav { list-style: none; }
	#nav li { float: left; }
	#rightnav li { float: right; }
	#nav li a { margin: 0 6px 0 0; font-size: 15px; display: block; padding: 8px 15px; text-decoration: none; color: #000; background-image: linear-gradient(to right, #FFE100 0%, #FFB400 51%, #FFE100 100%);
		flex: 1 1 auto;
		text-align: center;
		text-transform: uppercase;
		transition: 0.5s;
		background-size: 200% auto;
		border-radius: 10px;
		font-weight: 900;
		color: #fff;}	
	#nav li a:hover {background-position: right center; }
	#nav a:link, a:visited {border-radius: 12px 12px 12px 12px; }
	

	</style>
</head>
<body>
	<div>
		<ul id="nav">
		<li><a href='<?php echo site_url('')?>'>Home</a></li>
		<li><a href='<?php echo site_url('main/supplier')?>'>Supplier</a></li>
		<li><a href='<?php echo site_url('main/driver')?>'>Driver</a></li>
		<li><a href='<?php echo site_url('main/drivercard')?>'>Driver ID Card</a></li>
		<li><a href='<?php echo site_url('main/vehicle')?>'>Vehicle</a></li>
		<li><a href='<?php echo site_url('main/venue')?>'>Venue</a></li>
		<li><a href='<?php echo site_url('main/delivery')?>'>Delivery</a></li>
		<li><a href='<?php echo site_url('main/access_attempt_log')?>'>Access Atttempt Log</a></li>

			<ul id="rightnav">
			<li><a href='<?php echo site_url('main/help')?>'>Help</a></li>
			<li><a href='<?php echo site_url('main/historynav')?>'>History</a></li>
			</ul>
		</ul>
	</div>
</body>
</html>