<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<style>
		h1 { text-align: center; font-family: sans-serif ; font-weight: 900;  font-size: 2em; text-transform: uppercase;color: white; }
		p.p-centre { text-align: center; font-family: sans-serif; font-weight: 600; font-size: 1.5em; color: #8D8A80;}
		#cogs { display: block; padding-top: 20px; margin-left: auto; margin-right: auto; }	

		body {
		background: #353535;
		margin: 0; padding:0;}

	</style>
</head>
<body>

<h1>Delivery Access Management for Invicitus Games Events</h1>

<p class="p-centre">Welcome to DAMIGE System! Click one of the navigation links to begin.</p>

<div align="center">
	<img id="cogs" src="assets/images/Invictus-Games-2018.jpg" alt="Cogs and gears" height="449.4" width="840">	
	<!--Image credits: http://www.invictusgames2018.org/ -->
</div>
</body>
</html>