<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<style>
		h1 { text-align: center; font-family: sans-serif ; font-weight: 900;  font-size: 2em; text-transform: uppercase;color: white; }
		h2 { text-align: center; font-family: sans-serif ; font-weight: 900;  font-size: 1.5em; text-transform: uppercase;color: white; }
		body {
		background: #353535;
		margin: 0; padding:0;}
		table.mytable {border-collapse: collapse;}
		table.mytable td, th {border: 3px solid black; padding: 5px 15px 2px 7px; background: white; font-family: sans-serif ;}
		th {background-color: #EB5400;}	
		button{font-size: 11px; padding: 8px 10px; text-decoration: none; color: #000; background-image: linear-gradient(to right, #EB5400 0%, #FFB400 51%, #EB5400 100%);
		flex: 1 1 auto;
		text-align: center;
		text-transform: uppercase;
		transition: 0.5s;
		background-size: 200% auto;
		border-radius: 10px;
		font-weight: 900;
		color: #fff;
		border: 0 none;}
		button:hover{background-position: right center; }
	}		
	</style>
</head>
<body>

<h1>History</h1>
<div align='center'>
	<button type="submit" onclick="location.href='<?php echo site_url('main/query_historysupplier')?>'">Supplier History</button>
	<button type="submit" onclick="location.href='<?php echo site_url('main/query_historydriver')?>'">Driver History</button>
	<button type="submit" onclick="location.href='<?php echo site_url('main/query_historydriverid')?>'">Driver ID Card History</button>
	<button type="submit" onclick="location.href='<?php echo site_url('main/query_historyvehicle')?>'">Vehicle History</button>
	<button type="submit" onclick="location.href='<?php echo site_url('main/query_historyvenue')?>'">Venue History</button>
	<button type="submit" onclick="location.href='<?php echo site_url('main/query_historydelivery')?>'">Delivery History</button>	
</div>
<h2>Driver ID Card History</h2>
<div align='center'>
<?php
	$tmpl = array ('table_open' => '<table class="mytable">');
	$this->table->set_template($tmpl); 
	
	$this->db->query('drop table if exists temp');
	$this->db->query('create temporary table temp as (select cardID as "Card ID", startDate as "Start Date", endDate as "End Date", idState as "ID State", driveridcard_driverID as "Driver", action as "Action", actionDate as "Action Date" from history_driveridcard)');
	$query = $this->db->query('select * from temp;');
	echo $this->table->generate($query);
?>
</div>
</body>
</html>
