<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<style>
		h1 { text-align: center; font-family: sans-serif; font-weight: 750; font-size: 2em; text-transform: uppercase; color:white;}
		p.p-centre { text-align: center; font-family: sans-serif; font-weight: 500; font-size: 1.2em; color:white;}
		body {
		background: #353535;
		margin: 0; padding:0;}
		#myBtn {
		display: none; /* Hidden by default */
		position: fixed; /* Fixed/sticky position */
		bottom: 20px; /* Place the button at the bottom of the page */
		right: 30px; /* Place the button 30px from the right */
		z-index: 99; /* Make sure it does not overlap */
		border: none; /* Remove borders */
		outline: none; /* Remove outline */
		background-color: #000; /* Set a background color */
		background-image: linear-gradient(to right, #FFE100 0%, #FFB400 51%, #FFE100 100%);
		color: white; /* Text color */
		cursor: pointer; /* Add a mouse pointer on hover */
		padding: 15px; /* Some padding */
		border-radius: 10px; /* Rounded corners */
		font-size: 18px; /* Increase font size */
		}	
		#myBtn:hover {
		background-color: #555; /* Add a dark-grey background on hover */
		}
		#nav a:link, a:visited {color:white;}
		#nav { font-size:18px; 
		font-weight: 900;
		color: #fff;}
	</style>
</head>
<body>
<div>
	<button onclick="topFunction()" id="myBtn" title="Go to top">Back to top</button>
	<script>
	// When the user scrolls down 20px from the top of the document, show the button
	window.onscroll = function() {scrollFunction()};

	function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("myBtn").style.display = "block";
    } 
	else 
	{
        document.getElementById("myBtn").style.display = "none";
    }
	}

	// When the user clicks on the button, scroll to the top of the document
	function topFunction() 
	{
    document.body.scrollTop = 0; // For Safari
    document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
	}
	</script>
</div>
<h1>FAQ</h1>

<div id="nav" align="center">
	<a href="#supplier">Supplier</a>
	<a href="#driver">Driver</a>
	<a href="#driveridcard">Driver ID Card</a>
	<a href="#vehicle">Vehicle</a>
	<a href="#venue">Venue</a>
	<a href="#delivery">Delivery</a>
</div> <br></br>
<p class="p-centre"><strong>Q:</strong> Why am I unable to add this record?</p>
<p class="p-centre">DAMIGE prevents users from adding, and updating records which are already in existence. Please ensure that you’re are not adding data or updating to a data that already exists.</p>
<br />
<p id ="supplier" class="p-centre"><strong>Q:</strong> How do I add a supplier?</p>
<p class="p-centre">Navigate to the ‘Supplier’ page and select ‘Add Supplier’. Input the supplier details and select ‘Save’.</p>
<br />
<p class="p-centre"><strong>Q:</strong> How do I delete a supplier?</p>
<p class="p-centre">Navigate to the ‘Supplier’ page and select 'Delete’. Confirm that you would like to delete the supplier .</p>
<br />
<p class="p-centre"><strong>Q:</strong> How do I edit a supplier?</p>
<p class="p-centre">Navigate to the ‘Supplier’ page and select ‘Edit’. Input the changes to the supplier details and select ‘Update’.</p>
<br />
<p class="p-centre"><strong>Q:</strong> How do I view a supplier record?</p>
<p class="p-centre">Navigate to the ‘Supplier’ page and select 'View’. Select 'Back to list' to go back 'Supplier' page.</p>
<br />
<p class="p-centre"><strong>Q:</strong> How do I search for a specific supplier record?</p>
<p class="p-centre">Navigate to the ‘Supplier’ page and click on search bar at the right top corner of the table for general search or click on the specific column's search bar(s) and input the details.</p>
<br />
<p id="driver" class="p-centre"><strong>Q:</strong> How do I add a driver?</p>
<p class="p-centre">Navigate to the 'Driver' page and select ‘Add Driver. Input the driver details and select ‘Save’.</p>
<br />
<p class="p-centre"><strong>Q:</strong> How do I delete a driver?</p>
<p class="p-centre">Navigate to the ‘Driver’ page and select 'Delete’. Confirm that you would like to delete the driver .</p>
<br />
<p class="p-centre"><strong>Q:</strong> How do I edit a driver?</p>
<p class="p-centre">Navigate to the ‘Driver’ page and select ‘Edit’. Input the changes to the driver details and select ‘Update’.</p>
<br />
<p class="p-centre"><strong>Q:</strong> How do I view a driver record?</p>
<p class="p-centre">Navigate to the ‘Driver’ page and select 'View’. Select 'Back to list' to go back 'Driver' page.</p>
<br />
<p class="p-centre"><strong>Q:</strong> How do I search for a specific driver record?</p>
<p class="p-centre">Navigate to the ‘Driver’ page and click on search bar at the right top corner of the table for general search or click on the specific column's search bar(s) and input the details.</p>
<br />
<p id="driveridcard" class="p-centre"><strong>Q:</strong> How do I add a driver ID card?</p>
<p class="p-centre">Navigate to the 'Driver ID Card' page and select ‘Add Driver ID Card. Input the driver ID card details and select ‘Save’.</p>
<br />
<p class="p-centre"><strong>Q:</strong> How do I delete a driver ID card?</p>
<p class="p-centre">Navigate to the ‘Driver ID Card’ page and select 'Delete’. Confirm that you would like to delete the driver ID card.</p>
<br />
<p class="p-centre"><strong>Q:</strong> How do I edit a driver ID card?</p>
<p class="p-centre">Navigate to the ‘Driver ID Card’ page and select ‘Edit’. Input the changes to the driver ID card details and select ‘Update’.</p>
<br />
<p class="p-centre"><strong>Q:</strong> How do I view a driver ID card record?</p>
<p class="p-centre">Navigate to the ‘Driver ID Card’ page and select 'View’. Select 'Back to list' to go back 'Driver ID Card' page.</p>
<br />
<p class="p-centre"><strong>Q:</strong> How do I search for a specific driver IDrecord?</p>
<p class="p-centre">Navigate to the ‘Driver ID Card’ page and click on search bar at the right top corner of the table for general search or click on the specific column's search bar(s) and input the details.</p>
<br />
<p id="vehicle" class="p-centre"><strong>Q:</strong> How do I add a vehicle?</p>
<p class="p-centre">Navigate to the ‘Vehicle’ page and select ‘Add Vehicle’. Input the vehicle details and select ‘Save’.</p>
<br />
<p class="p-centre"><strong>Q:</strong> How do I delete a vehicle?</p>
<p class="p-centre">Navigate to the ‘Vehicle’ page and select 'Delete’. Confirm that you would like to delete the vehicle .</p>
<br />
<p class="p-centre"><strong>Q:</strong> How do I edit a vehicle?</p>
<p class="p-centre">Navigate to the ‘Vehicle’ page and select ‘Edit’. Input the changes to the vehicle details and select ‘Update’.</p>
<br />
<p class="p-centre"><strong>Q:</strong> How do I view a vehicle record?</p>
<p class="p-centre">Navigate to the ‘Vehicle’ page and select 'View’. Select 'Back to list' to go back 'Vehicle' page.</p>
<br />
<p class="p-centre"><strong>Q:</strong> How do I search for a specific vehicle record?</p>
<p class="p-centre">Navigate to the ‘Vehicle’ page and click on search bar at the right top corner of the table for general search or click on the specific column's search bar(s) and input the details.</p>
<br />
<p id="venue" class="p-centre"><strong>Q:</strong> How do I add a venue?</p>
<p class="p-centre">Navigate to the ‘Venue’ page and select ‘Add Venue. Input the venue details and select ‘Save’.</p>
<br />
<p class="p-centre"><strong>Q:</strong> How do I delete a venue?</p>
<p class="p-centre">Navigate to the ‘Venue’ page and select 'Delete’. Confirm that you would like to delete the venue .</p>
<br />
<p class="p-centre"><strong>Q:</strong> How do I edit a venue?</p>
<p class="p-centre">Navigate to the ‘Venue’ page and select ‘Edit’. Input the changes to the venue details and select ‘Update’.</p>
<br />
<p class="p-centre"><strong>Q:</strong> How do I view a venue record?</p>
<p class="p-centre">Navigate to the ‘Venue’ page and select 'View’. Select 'Back to list' to go back 'Venue' page.</p>
<br />
<p class="p-centre"><strong>Q:</strong> How do I search for a specific venue record?</p>
<p class="p-centre">Navigate to the ‘Venue’ page and click on search bar at the right top corner of the table for general search or click on the specific column's search bar(s) and input the details.</p>
<br />
<p id="delivery" class="p-centre"><strong>Q:</strong> How do I add a delivery?</p>
<p class="p-centre">Navigate to the ‘Delivery’ page and select ‘Add Delivery. Input the delivery details and select ‘Save’.</p>
<br />
<p class="p-centre"><strong>Q:</strong> How do I delete a delivery?</p>
<p class="p-centre">Navigate to the ‘Delivery’ page and select 'Delete’. Confirm that you would like to delete the delivery .</p>
<br />
<p class="p-centre"><strong>Q:</strong> How do I edit a delivery?</p>
<p class="p-centre">Navigate to the ‘Delivery’ page and select ‘Edit’. Input the changes to the delivery details and select ‘Update’.</p>
<br />
<p class="p-centre"><strong>Q:</strong> How do I view a delivery record?</p>
<p class="p-centre">Navigate to the ‘Delivery’ page and select 'View’. Select 'Back to list' to go back 'Delivery' page.</p>
<br />
<p class="p-centre"><strong>Q:</strong> How do I search for a specific delivery record?</p>
<p class="p-centre">Navigate to the 'Delivery' page and click on search bar at the right top corner of the table for general search or click on the specific column's search bar(s) and input the details.</p>
<br />
<p class="p-centre"><strong>Q:</strong> I can't find the answer to my question. What do I do?</p>
<p class="p-centre">If you do not find the answer to your question listed within our FAQ's, you can always contact us directly.</p>

</body>
</html>