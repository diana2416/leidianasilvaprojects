<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<style>
		h1 { text-align: center; font-family: sans-serif ; font-weight: 900;  font-size: 2em; text-transform: uppercase;color: white; }
		body {
		background: #353535;
		margin: 0; padding:0;}	
		button{font-size: 13px; font-family: sans-serif ; padding: 5px 10px; border-radius: 8px; 
		text-align: center;
		}
		button:hover{background-position: right center; }
	</style>
<?php 
foreach($css_files as $file): ?>
	<link type="text/css" rel="stylesheet" href="<?php echo $file; ?>" />
<?php endforeach; ?>
<?php foreach($js_files as $file): ?>
	<script src="<?php echo $file; ?>"></script>
<?php endforeach; ?>
</head>
<body>

<h1>Access Attempt Log</h1>
    <div>
		<button type="submit" onclick="location.href='<?php echo site_url('main/query_accessattemptlog')?>'">View Access Attempt Log</button>
		<?php echo $output; ?>


    </div>
</body>
</html>
