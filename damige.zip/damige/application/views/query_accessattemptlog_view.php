<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<style>
		h1 { text-align: center; font-family: sans-serif ; font-weight: 900;  font-size: 2em; text-transform: uppercase;color: white; }
		h2 { text-align: center; font-family: sans-serif ; font-weight: 900;  font-size: 1.5em; text-transform: uppercase;color: white; }
		body {
		background: #353535;
		margin: 0; padding:0;}
		table.mytable {border-collapse: collapse;}
		table.mytable td, th {border: 3px solid black; padding: 5px 15px 2px 7px; background: white; font-family: sans-serif ;}
		th {background-color: #EB5400;}		
		button{font-size: 11px; padding: 8px 10px; text-decoration: none; color: #000; background-image: linear-gradient(to right, #EB5400 0%, #FFB400 51%, #EB5400 100%);
		flex: 1 1 auto;
		text-align: center;
		text-transform: uppercase;
		transition: 0.5s;
		background-size: 200% auto;
		border-radius: 10px;
		font-weight: 900;
		color: #fff;
		border: 0 none;}
		button:hover{background-position: right center; }
	}		
	</style>
</head>
<body>

<h1>Access Attempt Log</h1>
<div align='center'>
</div>
			<?php
				$tmpl = array ('table_open' => '<table class="mytable">');
				$this->table->set_template($tmpl); 
				$this->db->query('drop table if exists temp');
				$this->db->query('create temporary table temp as (select access_venueID as "Venue", access_date as "Date", access_vehicleID as "Vehicle", access_driverID as "Driver", access_cardID as "Driver ID Card",  allowed as "Allowed?" from handle_access_attempt_log)');
				$query = $this->db->query('select * from temp;');
				echo $this->table->generate($query);
			?>
</div>

</body>
</html>