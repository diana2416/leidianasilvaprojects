<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Main extends CI_Controller {
	 
	 function __construct()
	{
		parent::__construct();	 
		$this->load->database();
		$this->load->helper('url');
		$this->load->library('grocery_CRUD');
		$this->load->library('ajax_grocery_CRUD');
		$this->load->library('table');
	}
	
	public function index()
	{	
		$this->load->view('header');
		$this->load->view('home');
	}
	
	public function orders()
	{	
		$this->load->view('header');
		$crud = new grocery_CRUD();
		$crud->set_theme('datatables');
		
		//table name exact from database
		$crud->set_table('orders');
		
		//give focus on name used for operations e.g. Add Order, Delete Order
		$crud->set_subject('Order');
		
		//the columns function lists attributes you see on frontend view of the table
		$crud->columns('invoiceNo', 'date', 'custID', 'items');
	
		//the fields function lists attributes to see on add/edit forms.
		//Note no inclusion of invoiceNo as this is auto-incrementing
		$crud->fields('date', 'custID', 'items');
		
		//set the foreign keys to appear as drop-down menus
		// ('this fk column','referencing table', 'column in referencing table')
		$crud->set_relation('custID','customers','custID');
		
		//many-to-many relationship with link table see grocery crud website: www.grocerycrud.com/examples/set_a_relation_n_n
		//('give a new name to related column for list in fields here', 'join table', 'other parent table', 'this fk in join table', 'other fk in join table', 'other parent table's viewable column to see in field')
		$crud->set_relation_n_n('items', 'order_items', 'items', 'invoice_no', 'item_id', 'itemDesc');
		
		//form validation (could match database columns set to "not null")
		$crud->required_fields('invoiceNo', 'date', 'custID');
		
		//change column heading name for readability ('columm name', 'name to display in frontend column header')
		$crud->display_as('custID', 'CustomerID');
		
		$output = $crud->render();
		$this->orders_output($output);
	}
	
	function orders_output($output = null)
	{
		//this function links up to corresponding page in the views folder to display content for this table
		$this->load->view('orders_view.php', $output);
	}

	public function items()
	{	
		$this->load->view('header');
		$crud = new grocery_CRUD();
		$crud->set_theme('datatables');
		
		$crud->set_table('items');
		$crud->set_subject('item');
		$crud->columns('itemID', 'itemDesc', 'orders');
		$crud->fields('itemDesc', 'orders');
		$crud->required_fields('itemID', 'itemDesc');
		$crud->set_relation_n_n('orders', 'order_items', 'orders', 'item_id', 'invoice_no', 'invoiceNo');
		$crud->display_as('itemDesc', 'Description');
		
		$output = $crud->render();
		$this->items_output($output);
	}
	
	function items_output($output = null)
	{
		$this->load->view('items_view.php', $output);
	}
	public function customers()
	{	
		$this->load->view('header');
		$crud = new grocery_CRUD();
		$crud->set_theme('datatables');
		$crud->set_table('customers');
		$crud->set_subject('customer');
		$crud->fields('custID', 'custName', 'custAddress', 'custTown', 'custPostcode', 'custTel', 'custEmail');
		$crud->required_fields('custID', 'custName', 'custAddress', 'custTown', 'custPostcode', 'custTel', 'custEmail');
		$crud->display_as('custID', 'CustomerID');
		$crud->display_as('custName', 'Name');
		$crud->display_as('custAddress', 'Address');
		$crud->display_as('custTown', 'Town');
		$crud->display_as('custPostcode', 'Postcode');
		$crud->display_as('custTel', 'Phone');
		$crud->display_as('custEmail', 'Email');
		
		$output = $crud->render();
		$this->cust_output($output);
	}
	
	function cust_output($output = null)
	{
		$this->load->view('cust_view.php', $output);
	}
	
	public function orderline()
	{	
		$this->load->view('header');
		$crud = new grocery_CRUD();
		$crud->set_theme('datatables');
		$crud->set_table('order_items');
		$crud->set_subject('order line');
		$crud->fields('invoice_no', 'item_id', 'itemQty', 'itemPrice');
		$crud->set_relation('invoice_no','orders','invoiceNo');
		//have multiple columns show in one FK column by concatenation:  www.grocerycrud.com/forums/topic/479-concatenate-two-or-more-fields-into-one-field/
		$crud->set_relation('item_id','items','{itemID} - {itemDesc}');
		$crud->required_fields('invoice_no', 'item_id', 'itemQty', 'itemPrice');
		$crud->display_as('invoice_no', 'InvoiceNo');
		$crud->display_as('item_id', 'ItemID');
		$crud->display_as('itemQty', 'Quantity');
		$crud->display_as('itemPrice', 'Price');
		
		$output = $crud->render();
		$this->orderline_output($output);
	}
	
	function orderline_output($output = null)
	{
		$this->load->view('orderline_view.php', $output);
	}
	
	public function historynav()
	{	
		$this->load->view('header');
		$this->load->view('historynav_view');
	}
		
	public function query_historysupplier()
	{	
		$this->load->view('header');
		$this->load->view('query_historysupplier_view');
	}
	
	public function query_historydriver()
	{	
		$this->load->view('header');
		$this->load->view('query_historydriver_view');
	}

	public function query_historydriverid()
	{	
		$this->load->view('header');
		$this->load->view('query_historydriverid_view');
	}

	public function query_historyvehicle()
	{	
		$this->load->view('header');
		$this->load->view('query_historyvehicle_view');
	}

	public function query_historyvenue()
	{	
		$this->load->view('header');
		$this->load->view('query_historyvenue_view');
	}

	public function query_historydelivery()
	{	
		$this->load->view('header');
		$this->load->view('query_historydelivery_view');
	}
	
	public function help()
	{	
		$this->load->view('header');
		$this->load->view('help_view');
	}

	public function query_access_attempt_log()
	{	
		$this->load->view('header');
		$this->load->view('query_access_attempt_log_view');
	}
	
	public function supplier()
	{	
		$this->load->view('header');
		$crud = new grocery_CRUD();
		$crud->set_theme('datatables');
		
		$crud->set_table('supplier');
		$crud->set_subject('Supplier');
		$crud->columns('supplierID','name', 'supplierGoods', 'supplierAddr', 'mngerForename', 'mngerSurname');
		$crud->fields('name', 'supplierGoods', 'supplierAddr', 'mngerForename', 'mngerSurname');
		$crud->required_fields('supplierID', 'name', 'supplierGoods', 'supplierAddr', 'mngerForename', 'mngerSurname');
		$crud->display_as('supplierID', 'Supplier ID');
		$crud->display_as('name', 'Supplier');
		$crud->display_as('supplierGoods', 'Goods & Services');
		$crud->display_as('supplierAddr', 'Based In');
		$crud->display_as('mngerForename', 'Manager First Name');
		$crud->display_as('mngerSurname', 'Manager Last Name');


		$output = $crud->render();
		$this->supp_output($output);
		
	}
	
	function supp_output($output = null)
	{
		$this->load->view('supp_view.php', $output);
	}
	
	public function venue()
	{	
		$this->load->view('header');
		$crud = new grocery_CRUD();
		$crud->set_theme('datatables');
		
		$crud->set_table('venue');
		$crud->set_subject('Venue');
		$crud->columns('venueID', 'venStadium', 'venArea', 'venAddr', 'venPhone');
		$crud->fields('venStadium', 'venArea', 'venAddr', 'venPhone');
		$crud->required_fields('venueID', 'venStadium', 'venArea', 'venAddr', 'venPhone');
		$crud->display_as('venueID', 'Venue ID');
		$crud->display_as('venStadium', 'Stadium');
		$crud->display_as('venArea', 'Area');
		$crud->display_as('venAddr', 'Address');
		$crud->display_as('venPhone', 'Phone Number');
		
		$crud->set_rules('venPhone', 'Phone Number', 'numeric');
		
		$output = $crud->render();
		$this->venue_output($output);
		
	}
	
	function venue_output($output = null)
	{
		$this->load->view('venue_view.php', $output);
	}
	
	public function driver()
	{	
		$this->load->view('header');
		$crud = new grocery_CRUD();
		$crud->set_theme('datatables');
		$crud->set_table('driver');
		$crud->set_subject('Driver');
		$crud->columns('driverID', 'title', 'driverForename', 'driverSurname', 'driver_supplierID');
		$crud->fields('title', 'driverForename', 'driverSurname', 'driver_supplierID');
		$crud->required_fields('title', 'driverID', 'driverForename', 'driverSurname', 'driver_supplierID');
		$crud->display_as('driverID', 'Driver ID');
		$crud->display_as('driverForename', 'Driver First Name');
		$crud->display_as('driverSurname', 'Driver Last Name');
		$crud->display_as('title', 'Title');
		$crud->display_as('driver_supplierID', 'Supplier');
		//set the foreign keys to appear 	 as drop-down menus
		// ('this fk column','referencing table', 'column in referencing table')
		$crud->set_relation('driver_supplierID','supplier','name');
		
		$output = $crud->render();
		$this->driver_output($output);
	}
	
	function driver_output($output = null)
	{
		$this->load->view('driver_view.php', $output);
	}

	
	public function vehicle()
	{	
		$this->load->view('header');
		$crud = new grocery_CRUD();
		$crud->set_theme('datatables');
		$crud->set_table('vehicle');
		$crud->set_subject('Vehicle');
		$crud->columns('vehicleID', 'regNo', 'vehicleMake', 'vehicleModel', 'vehicle_supplierID');
		$crud->fields('regNo', 'vehicleMake', 'vehicleModel', 'vehicle_supplierID');
		$crud->required_fields('vehicleID', 'regNo', 'vehicleMake', 'vehicleModel', 'vehicle_supplierID');
		$crud->display_as('vehicleID', 'Vehicle ID');
		$crud->display_as('regNo', 'Registration Number');
		$crud->display_as('vehicleMake', 'Make');
		$crud->display_as('vehicleModel', 'Model');
		$crud->display_as('vehicle_supplierID', 'Supplier');
		//set the foreign keys to appear 	 as drop-down menus
		// ('this fk column','referencing table', 'column in referencing table')
		$crud->set_relation('vehicle_supplierID','supplier','name');
		
		$output = $crud->render();
		$this->vehicle_output($output);
	}
	
	function vehicle_output($output = null)
	{
		$this->load->view('vehicle_view.php', $output);
	}
	
	public function delivery()
	{	
		$this->load->view('header');
		$crud = new grocery_CRUD();
		//$crud = new ajax_grocery_CRUD();
		$crud->set_theme('datatables');
		$crud->set_table('delivery');
		$crud->set_subject('Delivery');
		$crud->columns('deliveryID', 'date', 'delivery_venueID', 'delivery_driverID', 'delivery_vehicleID', 'delivery_supplierID');
		$crud->fields('date','delivery_supplierID', 'delivery_driverID', 'delivery_vehicleID','delivery_venueID');
		$crud->required_fields('deliveryID', 'date', 'delivery_venueID', 'delivery_driverID', 'delivery_vehicleID', 'delivery_supplierID');
		$crud->display_as('deliveryID', 'Delivery ID');
		$crud->display_as('date', 'Date');
		$crud->display_as('delivery_venueID', 'Venue');
		$crud->display_as('delivery_driverID', 'Driver');
		$crud->display_as('delivery_vehicleID', 'Vehicle');
		$crud->display_as('delivery_supplierID', 'Supplier');
		//set the foreign keys to appear 	 as drop-down menus
		// ('this fk column','referencing table', 'column in referencing table')
		$crud->set_relation('delivery_venueID','venue','venStadium');
		$crud->set_relation('delivery_driverID','driver','{driver_supplierID} - {driverForename} {driverSurname}');
		$crud->set_relation('delivery_vehicleID','vehicle','{vehicle_supplierID} - {regNo}');
		$crud->set_relation('delivery_supplierID','supplier', '{supplierID} - {name}');
		
		$output = $crud->render();
		$this->delivery_output($output);
	}
	
	function delivery_output($output = null)
	{
		$this->load->view('delivery_view.php', $output);
	}

	public function drivercard()
	{	
		$this->load->view('header');
		$crud = new grocery_CRUD();
		$crud->set_theme('datatables');
		$crud->set_table('driveridcard');
		$crud->set_subject('Driver ID Card');
		$crud->columns('cardID', 'driveridcard_driverID', 'startDate', 'endDate', 'idState');
		$crud->fields('driveridcard_driverID', 'startDate', 'endDate', 'idState');
		$crud->required_fields('driveridcard_driverID', 'startDate', 'endDate', 'idState');
		$crud->display_as('cardID', 'Card ID');
		$crud->display_as('driveridcard_driverID', 'Driver');
		$crud->display_as('startDate', 'Start Date');
		$crud->display_as('endDate', 'End Date');	
		$crud->display_as('idState', 'State');
		//set the foreign keys to appear as drop-down menus
		// ('this fk column','referencing table', 'column in referencing table')
		$crud->set_relation('driveridcard_driverID','driver',' {driverID} - {driverForename} {driverSurname}');
		
		$output = $crud->render();
		$this->drivercard_output($output);
	}
	
	function drivercard_output($output = null)
	{
		$this->load->view('drivercard_view.php', $output);
	}
	
	public function access_attempt_log()
	{	
		$this->load->view('header');
		$crud = new grocery_CRUD();
		//$crud = new ajax_grocery_CRUD();
		$crud->set_theme('datatables');
		$crud->set_table('access_attempt_log');
		$crud->set_subject('Access Attempt Log');
		$crud->columns('access_cardID', 'access_driverID', 'access_vehicleID', 'access_venueID', 'access_date');
		$crud->fields('access_cardID','access_driverID', 'access_vehicleID', 'access_venueID', 'access_date');
		$crud->required_fields('access_cardID', 'access_driverID', 'access_vehicleID', 'access_venueID', 'access_date');
		$crud->display_as('access_venueID', 'Venue');
		$crud->display_as('access_date', 'Date');
		$crud->display_as('access_vehicleID', 'Vehicle');
		$crud->display_as('access_cardID', 'Driver ID Card');
		//$crud->display_as('Driver');
		$crud->display_as('access_driverID', 'Driver ID');
		//set the foreign keys to appear 	 as drop-down menus
		// ('this fk column','referencing table', 'column in referencing table')
		$crud->set_relation('access_venueID','venue','venStadium');
		$crud->set_relation('access_vehicleID','vehicle','{vehicle_supplierID} - {regNo}');
		//$crud->set_relation(driver','{driverForename} {driverSurname}');
		$crud->set_relation('access_driverID','driver', '{driverID} - {driverForename} {driverSurname}');
		$crud->set_relation('access_cardID','driveridcard', '{cardID} - {driveridcard_driverID} ({idState})');

		$crud->unset_delete();
		$crud->unset_edit();
		
		$output = $crud->render();
		$this->access_attempt_output($output);
	}
	
	function access_attempt_output($output = null)
	{
		$this->load->view('access_attempt_view.php', $output);
	}
}
